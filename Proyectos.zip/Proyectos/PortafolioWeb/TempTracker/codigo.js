// ==========================================
// CÓDIGO PRINCIPAL - TEMPTRACKER
// ==========================================

// Configuración de API Key y URL Base
const apiKey = "28b1f7c457f7438ca00235015260110"; // ⚠️ Reemplaza por tu clave real entre comillas
const baseUrl = "https://api.weatherapi.com/v1/current.json";

// Selección de elementos del DOM
const inputCiudad = document.querySelector("#input-ciudad");
const btnBuscar = document.querySelector("#btn-buscar");

const contenedorClima = document.querySelector("#clima-info");
const iconoClima = document.querySelector("#icono-clima");
const elemTemperatura = document.querySelector("#temperatura");
const elemCiudad = document.querySelector("#nombre-ciudad");
const elemCondicion = document.querySelector("#condicion");
const elemHumedad = document.querySelector("#humedad");
const elemViento = document.querySelector("#viento");

// Función asíncrona para consultar el clima
async function consultarClima(ciudad) {
    const ciudadLimpia = ciudad.trim();
    
    if (!ciudadLimpia) {
        alert("Por favor, ingresa el nombre de una ciudad.");
        return;
    }

    // Construcción segura de la URL codificando caracteres especiales (tildes/espacios)
    const url = `${baseUrl}?key=${apiKey}&q=${encodeURIComponent(ciudadLimpia)}&lang=es`;

    try {
        const respuesta = await fetch(url);

        // Si la respuesta HTTP no es exitosa (ejemplo: status 400 u 401)
        if (!respuesta.ok) {
            const errorDatos = await respuesta.json().catch(() => null);
            console.error("Error devuelto por WeatherAPI:", errorDatos);

            if (respuesta.status === 400 || respuesta.status === 404) {
                alert("Ciudad no encontrada. Revisa el nombre e intenta nuevamente.");
            } else if (respuesta.status === 401 || respuesta.status === 403) {
                alert("Error de API Key: Verifica que tu clave esté correcta entre comillas o espera unos minutos a que se active.");
            } else {
                alert("No se pudo obtener la información del clima.");
            }
            return;
        }

        const datos = await respuesta.json();

        // Actualización de la información en el DOM
        elemCiudad.textContent = `${datos.location.name}, ${datos.location.country}`;
        elemTemperatura.textContent = `${Math.round(datos.current.temp_c)}°C`;
        elemCondicion.textContent = datos.current.condition.text;
        elemHumedad.textContent = `${datos.current.humidity}%`;
        elemViento.textContent = `${datos.current.wind_kph} km/h`;

        // Asegurar que el protocolo HTTPS esté presente en el ícono
        let urlIcono = datos.current.condition.icon;
        if (urlIcono.startsWith("//")) {
            urlIcono = "https:" + urlIcono;
        }
        iconoClima.src = urlIcono;

        // Mostrar la tarjeta del clima
        contenedorClima.style.display = "block";

    } catch (error) {
        console.error("Error en la conexión:", error);
        alert("Error de red al intentar conectar con el servicio del clima.");
    }
}

// Evento al hacer clic en el botón Buscar
btnBuscar.addEventListener("click", () => {
    consultarClima(inputCiudad.value);
});

// Evento al presionar la tecla Enter dentro del input
inputCiudad.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
        consultarClima(inputCiudad.value);
    }
});