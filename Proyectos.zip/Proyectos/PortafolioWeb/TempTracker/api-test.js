// ==========================================
// PRUEBAS DE CONSUMO DE API CON QUOKKA.JS
// ==========================================

// 1. Coloca tu API Key ENTRE COMILLAS (imprescindible si contiene números)
const apiKey = "28b1f7c457f7438ca00235015260110"; 
const ciudadPrueba = "Lima";

// 2. Construcción de la URL de consulta
const urlTest = "https://api.weatherapi.com/v1/current.json?key=" + apiKey + "&q=" + ciudadPrueba + "&lang=es";

// 3. Petición HTTP usando fetch
fetch(urlTest)
    .then(function(respuesta) {
        return respuesta.json();
    })
    .then(function(datos) {
        // Al activar Quokka.js, verás los resultados al lado de cada línea
        console.log("Respuesta de la API:", datos);
        console.log("Ciudad:", datos.location.name);
        console.log("Temperatura (°C):", datos.current.temp_c);
        console.log("Humedad (%):", datos.current.humidity);
        console.log("Viento (km/h):", datos.current.wind_kph);
        console.log("Condición:", datos.current.condition.text);
    })
    .catch(function(error) {
        console.error("Error en la petición:", error);
    });